# How to launch a console app

- open a terminal.
- go to the 'src' folder.
- execute the command 'node consoleApp.js'.

# How to launch tests

- open a terminal.
- go to the 'tests' folder.
- execute the command 'npm install'.
- execute the command 'jest'.
