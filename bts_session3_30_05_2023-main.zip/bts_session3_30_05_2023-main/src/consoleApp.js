// READ THE FILE helloWorld.js AND EXTRACT THE FUNCTION IN A VARIABLE
const helloWorldFunction = require("./helloWorld.js");
// CALL/INVOKE THE FUNCTION
const response = helloWorldFunction();
// LOG THE RESPONSE IN MY CONSOLE
const text = JSON.stringify(response);
console.log(response);
