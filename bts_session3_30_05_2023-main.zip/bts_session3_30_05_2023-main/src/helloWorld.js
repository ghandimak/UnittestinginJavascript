function helloWorld() {
  const person = {
    age: 24,
    name: "John",
    srName: "Doe",
    eyeColor: "green",
    birthday: "1999-03-12",
    address: [
      "Carrer Nou de Sant Francesc",
      "42",
      "3r 1a",
      "08002",
      "Barcelona",
    ],
  };

  return person;
}

module.exports = helloWorld;
